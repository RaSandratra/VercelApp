﻿'use client'
import { useState, useEffect, useCallback } from 'react'

export default function QuestionSection({ sessionId, isLive: isLiveInitial, startTime, endTime }) {
  const [questions, setQuestions] = useState([])
  const [content, setContent] = useState('')
  const [authorName, setAuthorName] = useState('')
  const [loading, setLoading] = useState(false)
  const [submitError, setSubmitError] = useState('')
  const [submitSuccess, setSubmitSuccess] = useState(false)
  const [userVotes, setUserVotes] = useState(new Set())

  useEffect(() => {
    const stored = localStorage.getItem('userUpvotes')
    if (stored) {
      const ids = JSON.parse(stored)
      setUserVotes(new Set(ids))
    }
  }, [])

  const addVoteToStorage = (questionId) => {
    const newVotes = new Set(userVotes)
    newVotes.add(questionId)
    setUserVotes(newVotes)
    localStorage.setItem('userUpvotes', JSON.stringify([...newVotes]))
  }

  const [isLive, setIsLive] = useState(isLiveInitial)

  useEffect(() => {
    if (!startTime || !endTime) return
    const check = () => {
      const now = new Date()
      setIsLive(now >= new Date(startTime) && now <= new Date(endTime))
    }
    check()
    const interval = setInterval(check, 10000)
    return () => clearInterval(interval)
  }, [startTime, endTime])

  const fetchQuestions = useCallback(async () => {
    try {
      const res = await fetch(`/api/sessions/${sessionId}/questions`)
      if (res.ok) setQuestions(await res.json())
    } catch (error) {
      console.error('Erreur chargement questions:', error)
    }
  }, [sessionId])

  useEffect(() => {
    fetchQuestions()
    if (!isLive) return
    const interval = setInterval(fetchQuestions, 5000)
    return () => clearInterval(interval)
  }, [sessionId, isLive, fetchQuestions])

  const handleSubmit = async (e) => {
    e.preventDefault()
    if (!content.trim()) return
    setLoading(true)
    setSubmitError('')
    setSubmitSuccess(false)

    try {
      const res = await fetch(`/api/sessions/${sessionId}/questions`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ content, authorName: authorName || null }),
      })
      const data = await res.json().catch(() => ({}))

      if (res.ok) {
        setContent('')
        setAuthorName('')
        setSubmitSuccess(true)
        setTimeout(() => setSubmitSuccess(false), 3000)
        fetchQuestions()
      } else if (res.status === 403) {
        setIsLive(false)
        setSubmitError('âŒ La session n\'est plus en direct. Les questions sont fermÃ©es.')
      } else if (res.status === 400) {
        setSubmitError('âš ï¸ ' + (data.error || 'Le contenu de la question est requis.'))
      } else if (res.status === 404) {
        setSubmitError('âš ï¸ Session introuvable. Rechargez la page et rÃ©essayez.')
      } else {
        setSubmitError('âŒ ' + (data.error || 'Erreur lors de l\'envoi, rÃ©essayez.'))
      }
    } catch {
      setSubmitError('âŒ Erreur rÃ©seau. VÃ©rifiez votre connexion et rÃ©essayez.')
    } finally {
      setLoading(false)
    }
  }

  const handleUpvote = async (questionId) => {
    if (userVotes.has(questionId)) {
      setSubmitError('Vous avez dÃ©jÃ  votÃ© pour cette question.')
      setTimeout(() => setSubmitError(''), 2000)
      return
    }
    try {
      const res = await fetch(`/api/questions/${questionId}/upvote`, { method: 'POST' })
      if (res.ok) {
        addVoteToStorage(questionId)
        fetchQuestions()
      } else {
        setSubmitError('Erreur lors du vote.')
        setTimeout(() => setSubmitError(''), 2000)
      }
    } catch (error) {
      console.error('Erreur upvote:', error)
      setSubmitError('Erreur rÃ©seau.')
      setTimeout(() => setSubmitError(''), 2000)
    }
  }

  return (
    <div>
      <h3 className="text-xl font-bold mb-4 text-[#F9FAFB]">â“ Questions</h3>

      {isLive ? (
        <form onSubmit={handleSubmit} className="mb-6 space-y-3 bg-[#10B981]/15 border border-emerald-100 rounded-xl p-4">
          <p className="text-sm font-medium text-[#10B981]">ðŸ”´ Session en direct â€” posez votre question</p>
          <textarea
            className="w-full border border-white/15 p-2.5 rounded-lg text-sm focus:ring-2 focus:ring-emerald-400 outline-none resize-none"
            placeholder="Votre question..."
            rows={3}
            value={content}
            onChange={e => { setContent(e.target.value); setSubmitError('') }}
            required
          />
          <input
            className="w-full border border-white/15 p-2.5 rounded-lg text-sm focus:ring-2 focus:ring-emerald-400 outline-none"
            placeholder="Votre nom (optionnel)"
            value={authorName}
            onChange={e => setAuthorName(e.target.value)}
          />
          {submitError && (
            <div className="bg-red-500/10 border border-red-400/30 rounded-lg px-3 py-2 text-red-300 text-sm">
              {submitError}
            </div>
          )}
          {submitSuccess && (
            <div className="bg-[#10B981]/10 border border-[#10B981]/30 rounded-lg px-3 py-2 text-[#10B981] text-sm">
              âœ… Question envoyÃ©e avec succÃ¨s !
            </div>
          )}
          <button
            type="submit"
            disabled={loading}
            className="bg-[#10B981] hover:bg-emerald-700 disabled:opacity-50 text-white px-5 py-2 rounded-lg text-sm font-medium transition"
          >
            {loading ? 'Envoi en cours...' : 'Poser la question'}
          </button>
        </form>
      ) : (
        <div className="mb-6 bg-[#111827] border border-white/10 rounded-xl p-4">
          {submitError ? (
            <p className="text-red-500 text-sm">{submitError}</p>
          ) : (
            <p className="text-gray-400 text-sm">
              â³ Les nouvelles questions ne peuvent Ãªtre posÃ©es que lorsque la session est en direct.
            </p>
          )}
        </div>
      )}

      {questions.length === 0 ? (
        <p className="text-gray-400 text-sm text-center py-6">Aucune question pour le moment.</p>
      ) : (
        <div className="space-y-3">
          {questions.map(q => (
            <div key={q.id} className="bg-[#1F2937] border border-white/10 rounded-xl p-4 shadow-sm">
              <p className="text-[#F9FAFB] font-medium">{q.content}</p>
              <div className="flex justify-between items-center mt-3">
                <span className="text-xs text-gray-400">
                  {q.authorName || 'Anonyme'}
                </span>
                <button
                  onClick={() => handleUpvote(q.id)}
                  disabled={userVotes.has(q.id)}
                  className={`flex items-center gap-1.5 rounded-full text-xs font-medium transition px-3 py-1 ${
                    userVotes.has(q.id)
                      ? 'bg-[#10B981]/15 text-[#10B981] cursor-default'
                      : 'bg-[#1F2937] hover:bg-[#10B981]/15 hover:text-[#10B981] text-gray-400'
                  }`}
                >
                  ðŸ‘ {q.upvotes}
                  {userVotes.has(q.id) && <span className="ml-1">(dÃ©jÃ  votÃ©)</span>}
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  )
}




