﻿'use client'

import Link from 'next/link'
import { usePathname } from 'next/navigation'
import { signOut } from 'next-auth/react'
import {
  ArrowLeftEndOnRectangleIcon,
  ArrowTopRightOnSquareIcon,
  BuildingOfficeIcon,
  CalendarDaysIcon,
  ChartBarIcon,
  PlayCircleIcon,
  SparklesIcon,
  UserGroupIcon,
} from '@heroicons/react/24/outline'

const navItems = [
  { href: '/admin/dashboard', label: 'Tableau de bord', icon: ChartBarIcon },
  { href: '/admin/events', label: 'Événements', icon: CalendarDaysIcon },
  { href: '/admin/sessions', label: 'Sessions', icon: PlayCircleIcon },
  { href: '/admin/speakers', label: 'Intervenants', icon: UserGroupIcon },
  { href: '/admin/rooms', label: 'Salles', icon: BuildingOfficeIcon },
]

export default function AdminSidebar() {
  const pathname = usePathname()

  return (
    <aside className="fixed inset-y-0 left-0 z-40 hidden w-64 flex-col border-r border-white/10 bg-[#1F2937] shadow-sm lg:flex">
      <div className="border-b border-white/10 px-5 py-5">
        <Link href="/admin/dashboard" className="flex items-center gap-3 text-[#F9FAFB]">
          <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-[#10B981] text-white shadow-glow">
            <SparklesIcon className="h-5 w-5" />
          </div>
          <div>
            <p className="text-lg font-black tracking-tight">EventSync</p>
            <p className="text-xs font-medium text-gray-400">Administration</p>
          </div>
        </Link>
      </div>

      <nav className="flex-1 space-y-1 overflow-y-auto px-3 py-4">
        {navItems.map(({ href, label, icon: Icon }) => {
          const isActive = pathname === href || pathname.startsWith(`${href}/`)
          return (
            <Link
              key={href}
              href={href}
              className={`flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-semibold transition-all ${
                isActive
                  ? 'bg-[#10B981] text-white shadow-glow'
                  : 'text-gray-400 hover:bg-[#111827] hover:text-[#F9FAFB]'
              }`}
            >
              <Icon className="h-5 w-5 shrink-0" />
              {label}
            </Link>
          )
        })}
      </nav>

      <div className="space-y-2 border-t border-white/10 px-3 py-4">
        <Link
          href="/"
          className="flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-semibold text-gray-400 hover:bg-[#111827] hover:text-[#F9FAFB]"
        >
          <ArrowTopRightOnSquareIcon className="h-5 w-5" />
          Site public
        </Link>
        <button
          onClick={() => signOut({ callbackUrl: '/login' })}
          className="flex w-full items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-semibold text-gray-400 hover:bg-red-500/10 hover:text-red-300"
        >
          <ArrowLeftEndOnRectangleIcon className="h-5 w-5 shrink-0" />
          Déconnexion
        </button>
      </div>
    </aside>
  )
}





